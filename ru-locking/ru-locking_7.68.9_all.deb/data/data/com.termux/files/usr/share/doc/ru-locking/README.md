# ==========================================
# 1. Pattern Selection & Interpretation
# ==========================================

# -i, --ignore-case (Ignore case differences)
locking -i "main" src/

# -w, --word-regexp (Search for whole/exact words)
locking -w "fn" src/

# -x, --line-regexp (Search for exact full-line matches)
locking -x "fn main() {" src/

# -v, --invert-match (Show lines that do NOT match)
locking -v "TODO" src/


# ==========================================
# 2. Directory & File Filtering (Advanced)
# ==========================================

# -D, --dir, --directories (Search for directory/folder names)
locking -D "config" .

# --hidden (Include hidden files/folders like .env or .git)
locking --hidden "DATABASE_URL" .

# --no-ignore (Ignore .gitignore rules)
locking --no-ignore "secret" .

# -e, --extension=EXT (Filter by file extension)
locking -e rs,toml "tokio" .
locking --extension=md "Usage" . # -r, -R, --recursive (Search recursively within a folder)
locking -r "cargo" src/


# ==========================================
# 3. Output Control
# ==========================================

# -m, --max-count=NUM (Limit the number of matching lines)
locking -m 5 "fn" src/

# -n, --line-number (Show line numbers)
locking -n "struct" src/

# -H, --with-filename (Always show the filename in the output)
locking -H "main" src/main.rs

# -h, --no-filename (Hide the filename from the output)
locking -h "main" src/

# -o, --only-matching (Show only the matching text, not the entire line)
locking -o "fn [a-z_]+" src/

# -q, --quiet, --silent (Run without text output)
locking -q "error" app.log

# -l, --files-with-matches (Show only filenames with matches)
locking -l "pub" src/

# -L, --files-without-match (Show only filenames without matches)
locking -L "pub" src/

# -c, --count (Show the number of matching lines per file)
locking -c "let" src/


# ==========================================
# 4. Context Control
# ==========================================

# -B, --before-context=NUM (Show N lines BEFORE the match)
locking -B 3 "panic!" src/

# -A, --after-context=NUM (Show N lines AFTER the match)
locking -A 3 "panic!" src/

# -C, --context=NUM (Show N lines before and after the match)
locking -C 2 "Error" src/

# --color[=WHEN] (Use color highlighting)
locking --color=always "fn" src/


# ==========================================
# 5. Miscellaneous & Input Stream (Piping)
# ==========================================

# -I, --interactive (Open interactive TUI search mode)
locking -I

# -s, --no-messages (Suppress error messages)
locking -s "pattern" /invalid/path/

# -V, --version (Show application version)
locking -V

# --help (Show help guide)
locking --help

# Accepting Pipe Input (stdin)
history | locking "cargo"
cat Cargo.toml | locking -i "dependencies"